#ifndef __ADDR_H_
#define __ADDR_H_

#include <stdint.h>

void qrtr_set_address(uint32_t addr);

#endif
