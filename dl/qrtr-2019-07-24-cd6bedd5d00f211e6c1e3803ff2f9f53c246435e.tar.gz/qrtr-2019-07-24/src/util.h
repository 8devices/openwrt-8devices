#ifndef __UTIL_H_
#define __UTIL_H_

#include <stdint.h>

uint64_t time_ms(void);
void util_sleep(int ms);

#endif
