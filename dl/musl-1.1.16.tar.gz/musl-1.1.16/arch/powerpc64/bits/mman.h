#define PROT_SAO       0x10

#undef MCL_CURRENT
#define MCL_CURRENT     0x2000
#undef MCL_FUTURE
#define MCL_FUTURE      0x4000
#undef MCL_ONFAULT
#define MCL_ONFAULT     0x8000
